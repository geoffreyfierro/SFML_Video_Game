//
// Created by geoff on 5/14/2020.
//

#include "GFGame.h"

GFGame::GFGame() {

    image_path = "GFGame/Pictures/thumbnail.png";
    title = "Texas Hold'em";
    logo = new GameText(title, 96, sf::Vector2f(0,0));
    win = new sf::RenderWindow();

    westernFont = new sf::Font();
    westernFont->loadFromFile("GFGame/Fonts/CarnevaleeFreakshow.ttf");

    titleText = new sf::Text(title, *westernFont, 96);
    subTitleText = new sf::Text("Click to Start", *westernFont, 48);

    startGame = false;

}

void GFGame::start(sf::RenderWindow &window) {
    logo->getText()->setPosition(window.getSize().x/2 -logo->getText()->getGlobalBounds().width/2, window.getSize().y/2 -logo->getText()->getGlobalBounds().height/2 );


}

void GFGame::addEvents(sf::RenderWindow &window) {
    if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
        startGame = true;
    }
}

void GFGame::addEvents(const sf::RenderWindow &window, sf::Event &event) {

}

void GFGame::draw(sf::RenderTarget &window, sf::RenderStates states) const {

    titleText->setPosition(window.getSize().x/2 - titleText->getGlobalBounds().width/2,window.getSize().y/2 - titleText->getGlobalBounds().height/2);
    subTitleText->setPosition(window.getSize().x/2 - subTitleText->getGlobalBounds().width/2, titleText->getPosition().y + (titleText->getGlobalBounds().height*2));
    if(!startGame){
        window.draw(*titleText);
        window.draw(*subTitleText);
    }
    else if(startGame){

    }

}

void GFGame::exit() {

}
