//
// Created by Dave R. Smith on 10/25/19.
//

#ifndef TEST_STATIC_GAME_INTERFACE_H
#define TEST_STATIC_GAME_INTERFACE_H



#include <string>
#include <map>
#include <string>
#include <SFML/Graphics.hpp>
using std::string;

class Game_Interface {


public:
    //virtual sf::Sprite getThumbnail() = 0;
    //virtual string getTitle() = 0;

    Game_Interface();

};


#endif //TEST_STATIC_GAME_INTERFACE_H
