//
// Created by geoff on 5/14/2020.
//

#ifndef SFML_PROJECT_GFGAME_H
#define SFML_PROJECT_GFGAME_H

#include <SFML/Graphics.hpp>
#include "Game.h"
#include <vector>


class GFGame : public Game{
private:
    GameText *logo;

    sf::Font *westernFont;
    sf::Text *titleText;
    sf::Text *subTitleText;
    sf::RenderTarget *win;

    bool startGame;

public:
    GFGame();

    virtual void start(sf::RenderWindow& window);
    virtual void addEvents(sf::RenderWindow &window);
    virtual void addEvents(const sf::RenderWindow &window, sf::Event& event);
    virtual void draw(sf::RenderTarget &window, sf::RenderStates states) const;
    virtual void exit();
};


#endif //SFML_PROJECT_GFGAME_H
